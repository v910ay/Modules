﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FRS.ENTITY;
using FRS.EXCEPTION;

namespace FRS.DAL
{
    public class FlightOperations
    {
        //static FlightEntities context = new FlightEntities();
        public static Flight SearchFlight(Flight f)
        {
            FlightEntities db = new  FlightEntities();
            Flight flight = null;

            try 
            {
                flight = (from s in db.Flights
                        where s.Source == f.Source && s.Destination==f.Destination && s.DateOfJourney==f.DateOfJourney
                        select s).FirstOrDefault();

                if(flight==null)
                {
                    throw new FlightException("Flight not found.");
                }
            }
            catch (FlightException ex)
            {
                throw ex;
            }
          
            catch (SystemException ex)
            {
                throw ex;
            }

            return flight;
        }

        public static Flight RetrieveFlight(Flight f)
        {
            Flight flight = null;
            FlightEntities db=new  FlightEntities();
            try
            {
               flight = (from item in db.Flights where item.Source.Equals(f.Source) && item.Destination.Equals(f.Destination) && item.DateOfJourney.Equals(f.DateOfJourney) select item).FirstOrDefault();
            }
            catch(FlightException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return flight;
        }

        public static Users_UAS SearchAdmin(Users_UAS Admin)
        {
             FlightEntities db = new  FlightEntities();
             Users_UAS U1 = null;

            try 
            {
                U1 = (from u in db.Users_UAS
                        where u.UserName == Admin.UserName && u.password==Admin.password select u).FirstOrDefault();
                     

                if(U1==null)
                {
                    throw new FlightException("Access denied. Please enter correct username and password");
                }
            }
            catch (FlightException ex)
            {
                throw ex;
            }
          
            catch (SystemException ex)
            {
                throw ex;
            }

            return U1;
        }

        public static int addflight(Flight f)
        {

            FlightEntities db = new FlightEntities();
            int records;
            try
            {
                db.Flights.Add(f);

                records = db.SaveChanges();
            }
            catch(FlightException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return records ;
        }

        //Remove flight (Admin)
        public static int removeflight(string fid)
        {
            FlightEntities db = new  FlightEntities();
            int records;
            try
            {  
                Flight flighttobedeleted=(from f in db.Flights
                                              where f.FlightID==fid select f).FirstOrDefault(); 
                if(flighttobedeleted!=null)
                {
                    db.Flights.Remove(flighttobedeleted);
                    records = db.SaveChanges();
                }
                else
                {
                    throw new FlightException("Record not found for Deletion");
                }
            }
            catch (FlightException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

    }
    }

