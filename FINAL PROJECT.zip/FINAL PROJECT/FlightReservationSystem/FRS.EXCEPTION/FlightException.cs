﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FRS.EXCEPTION
{
    public class FlightException:ApplicationException
    {
        public FlightException()
            : base()
        {

        }
        public FlightException(string message)
            : base(message)
        {

        }
    }
}
