﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FRS.EXCEPTION;
using FRS.ENTITY;
using FRS.DAL;
using System.Text.RegularExpressions;

namespace FRS.BL
{
    public class FlightValidation
    {
        public static bool ValildateFlight(Flight f)
        {
            bool flightValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {

                if (f.Destination == string.Empty)
                {
                    flightValidated = false;
                    message.Append("Flight name should be provided\n");
                }
                if (f.Source == String.Empty)
                {
                    flightValidated = false;
                    message.Append("Flight name should be provided\n");
                }
                if (f.DateOfJourney == null)
                {
                    flightValidated = false;
                    message.Append("Flight name should be provided\n");
                }
                if (f.DateOfJourney < DateTime.Today)
                {
                    flightValidated = false;
                    message.Append("Journey date should be greater than current date");
                }
                if (f.DateOfJourney > DateTime.Today.AddDays(10))
                {
                    flightValidated = false;
                    message.Append("Journey date should be between 01/12/2017 and 10/12/2017");
                }

                if (f.DateOfJourney == null)
                {
                    flightValidated = false;
                    message.Append("Flight name should be provided\n");
                }
                if (f.DateOfJourney < DateTime.Today)
                {
                    flightValidated = false;
                    message.Append("Journey date should be greater than current date");
                }
                if (f.DateOfJourney > DateTime.Today.AddDays(10))
                {
                    flightValidated = false;
                    message.Append("Journey date should be between 01/12/2017 and 10/12/2017");
                }

                if (f.Destination.Equals(f.Source))
                {
                    flightValidated = false;
                    message.Append("Origin and Destination cannot be same.");
                }

                if (flightValidated == false)
                    throw new FlightException(message.ToString());

            }
            catch (FlightException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return flightValidated;
        }

        public static Flight SearchFlight(Flight f)
        {
            Flight flight = null;

            try
            {
                flight = FlightOperations.SearchFlight(f);
            }
            catch (FlightException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return flight;
        }
        public static Flight RetrieveFlight(Flight f)
        {
            Flight flight = null;

            try
            {
                flight = FlightOperations.RetrieveFlight(f);
            }
            catch (FlightException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return flight;
        }
        public static bool ValildateCustomer(Customer c)
        {
            bool ValidateCust = true;
            StringBuilder message = new StringBuilder();
            try
            {
                if (c.Name == string.Empty)
                {
                    ValidateCust = false;
                    message.Append("Name should be provided\n");
                }
                if (c.MobileNo == string.Empty)
                {
                    ValidateCust = false;
                    message.Append("Mobile Number should be provided\n");
                }
                if (c.Email == string.Empty)
                {
                    ValidateCust = false;
                    message.Append("EmailID should be provided\n");
                }
                if (!Regex.IsMatch(c.Email, "[a-z0-9]{1,}[@][a-z]{4,}[.][c][o][m]"))
                {
                    ValidateCust = false;
                    message.Append("EmailID should be in correct format as abc123@xyz.com\n");
                }
                if (c.Gender == string.Empty)
                {
                    ValidateCust = false;
                    message.Append("Gender should be Selected\n");
                }
                if (c.DOB == null)
                {
                    ValidateCust = false;
                    message.Append("Date Of birth should be provided\n");
                }
              
                if (c.NoOfTickets==0)
                {
                    ValidateCust = false;
                    message.Append("Number of Tickets cannot be zero");
                }
                if (ValidateCust == false)
                    throw new FlightException(message.ToString());


            }
            catch (FlightException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ValidateCust;
        }

        public static Users_UAS SearchAdmin(Users_UAS Admin)
        {
            Users_UAS U1 = null;

            try
            {
                U1 = FlightOperations.SearchAdmin(Admin);
            }
            catch (FlightException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return U1;
        }

       public static bool FlightAdditionValidation(Flight f)
        {
            bool flightadditionValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Flight Id validation
                if (f.FlightID == String.Empty)
                {
                    flightadditionValidated = false;
                    message.Append("Flight ID should be provided\n");
                }
                if(!Regex.IsMatch(f.FlightID, "[C][G][-][4-9][0-9]{2}"))
                {
                    message.Append("Flight ID should start with 'CG-' followed by three digit number from 400 to 999");
                    flightadditionValidated = false;
                }
                //Flight source validation
                if (f.Source == String.Empty)
                {
                    flightadditionValidated = false;
                    message.Append("Flight source should be provided\n");
                }
                if (!Regex.IsMatch(f.Source, "[A-Za-z]+"))
                {
                    message.Append("Source should have only alphabets");
                    flightadditionValidated = false;
                }
                //Flight destination validation
                if (f.Destination == String.Empty)
                {
                    flightadditionValidated = false;
                    message.Append("Flight destination should be provided\n");
                }
                if (!Regex.IsMatch(f.Destination, "[A-Za-z]+"))
                {
                    message.Append("destination should have only alphabets");
                    flightadditionValidated = false;
                }
                //Flight source and destionation equality validation
                if(f.Source.ToLower()==f.Destination.ToLower())
                {
                    message.Append("Source and Destination cannot be same");
                    flightadditionValidated = false;
                }
                //Flight departure time validation
                if (f.DeptTime == String.Empty)
                {
                    flightadditionValidated = false;
                    message.Append("Flight Departure time should be provided\n");
                }
                if (!Regex.IsMatch(f.DeptTime, "[0-2][0-9][:][0-59]"))
                {
                    message.Append("Departure time should be in 'hh:mm' format");
                    flightadditionValidated = false;
                }
                //Flight arrivaltime validation
                if (f.ArrivalTime == String.Empty)
                {
                    flightadditionValidated = false;
                    message.Append("Flight Arrival time should be provided\n");
                }
                if (!Regex.IsMatch(f.ArrivalTime, "[0-2][0-9][:][0-59]"))
                {
                    message.Append("Arrival time should be in 'hh:mm' format");
                    flightadditionValidated = false;
                }
                //Flight departure time and arrival time equality validation
                if(f.DeptTime==f.ArrivalTime)
                {
                    message.Append("Departure time and arrival time should not be same");
                    flightadditionValidated=false;
                }
                //Flight number of seats validation
                if(f.TotalNoOfSeats==null)
                {
                    message.Append("Total number of seats should be provided");
                    flightadditionValidated=false;
                }
                //if(!Regex.IsMatch(f.TotalNoOfSeats),"[1][0-9]{2}"))
                //{
                //    message.Append("Total number of seats should be an integer");
                //    flightadditionValidated=false;
                //}
                //Flight price validation
                if(f.Fare==null)
                {
                    message.Append("Fare should be provided");
                    flightadditionValidated=false;
                }
                //if(!Regex.IsMatch(f.Fare,"[1][0-9]{3,}"))
                //{
                //    message.Append("Fare should be a decimal value");
                //    flightadditionValidated=false;
                //}
                 if (flightadditionValidated == false)
                    throw new FlightException(message.ToString());
            }

            catch (FlightException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return flightadditionValidated;
        }

       public static int addflight(Flight f)
       {
           int records = 0;

           try
           {
               if (FlightAdditionValidation(f))
               {
                   records = FlightOperations.addflight(f);
               }
               else
                   throw new FlightException("Please provide valid information");
           }
           catch (FlightException ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return records;
       }

        //Remove flight (Admin)
        public static int removeflight(string fid)
       {
           int records;
            try
           {
               records = FlightOperations.removeflight(fid);
           }
           catch (FlightException ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }
           return records;

       }
    }
    
}
    

