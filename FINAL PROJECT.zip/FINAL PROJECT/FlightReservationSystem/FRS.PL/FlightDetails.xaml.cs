﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FRS.ENTITY;
using FRS.BL;

namespace FRS.PL
{
    /// <summary>
    /// Interaction logic for FlightDetails.xaml
    /// </summary>
    public partial class FlightDetails : Window
    {
        public Flight F;
        public FlightDetails()
        {
            InitializeComponent();
        }
        public FlightDetails(Flight f)
        {
            InitializeComponent();
            F = f;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Flight f2 = FlightValidation.RetrieveFlight(F);
            lbldisflightid.Content = f2.FlightID;
            lbldissource.Content = f2.Source;
            lbldisnoofavailable.Content = f2.TotalNoOfSeats;
            lbldisdateofjourney.Content = f2.DateOfJourney;
            lbldisdestination.Content = f2.Destination;
            lbldisdeparturetime.Content = f2.DeptTime;
            lbldisarrival.Content = f2.ArrivalTime;
            lbldisfare.Content = f2.Fare;
        }

        private void btnBook_Click(object sender, RoutedEventArgs e)
        {

            BookingDetails b = new BookingDetails(F);
            b.Show();

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow m = new MainWindow();
            m.Show();
            FlightDetails f = new FlightDetails();
            f.Close();
        }
    }
}
