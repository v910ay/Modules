﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FRS.ENTITY;
using FRS.EXCEPTION;
using FRS.BL;


namespace FRS.PL
{
    /// <summary>
    /// Interaction logic for AdminLogin.xaml
    /// </summary>
    public partial class AdminLogin : Window
    {
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, RoutedEventArgs e)
        {
            Users_UAS admin = new Users_UAS();
            admin.UserName = txtusername.Text;
            admin.password = txtpassword.Password.ToString();
            Users_UAS a=FlightValidation.SearchAdmin(admin);
            if(a!=null)
            {
                FlightManagement fm = new FlightManagement();
                fm.Show();
                this.Close();
            }
        }
    }
}
