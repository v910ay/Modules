﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FRS.ENTITY;
using FRS.EXCEPTION;

namespace FRS.PL
{
    /// <summary>
    /// Interaction logic for BookingConfirmation.xaml
    /// </summary>
    public partial class BookingConfirmation : Window
    {
        List<Customer> nc1;
        Flight nf;
        int fare;
        FlightEntities context = new FlightEntities();
        public BookingConfirmation()
        {
            InitializeComponent();
        }
        public BookingConfirmation(List<Customer> c, int price, Flight fn)
        {
            InitializeComponent();
            nc1 = c;
            fare = price;
            nf = fn;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < nc1.Count; i++)
            {
                Reservation db = new Reservation();

                db.ContacNo = long.Parse(nc1[i].MobileNo.ToString());
                db.DateofBooking = DateTime.Today;
                db.Email = nc1[i].Email;
                db.FlightID = nf.FlightID;
                db.JourneyDate = nf.DateOfJourney;
                db.NoofTickets = nc1[i].NoOfTickets + 1;
                db.PassengerName = nc1[i].Name;
                db.Status = "Confirmed";
                db.TotalFare = fare;
                context.Reservations.Add(db);
                context.SaveChanges();
                btnSave.IsEnabled = false;
                //dgTicket.Items.Add(db);
            }
            // dgTicket.AutoGenerateColumns = false;
            dgTicket.DataContext = context.Reservations.ToList();

        }
    }
}

