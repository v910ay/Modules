﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FRS.BL;
using FRS.ENTITY;
using FRS.EXCEPTION;

namespace FRS.PL
{
    /// <summary>
    /// Interaction logic for FlightManagement.xaml
    /// </summary>
    public partial class FlightManagement : Window
    {
        public FlightManagement()
        {
            InitializeComponent();
        }

        private void btnaddflight_Click(object sender, RoutedEventArgs e)
        {
            addcanvas.Visibility = Visibility.Visible;
            
        }

        private void btnaddAdminflight_Click(object sender, RoutedEventArgs e)
        {
            Flight flight = new Flight();
            flight.FlightID = txtaddID.Text;
            flight.Source = txtaddsource.Text;
            flight.Destination = txtaddDestination.Text;
            flight.DateOfJourney = DateTime.Today;
            flight.DeptTime = txtaddDeparturetime.Text;
            flight.ArrivalTime = txtaddArrivaltime.Text;
            flight.TotalNoOfSeats = Convert.ToInt32(txtaddSeats.Text);
            flight.Fare = Convert.ToDecimal(txtaddPrice.Text);
            try
            {
                int records = FlightValidation.addflight(flight);
                if (records > 0)
                {
                    MessageBox.Show("Flight added successfully!!");
                }
                else
                    throw new FlightException("Flight not added.");
            }
            catch(FlightException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
               
        }

        private void btnremoveflight_Click(object sender, RoutedEventArgs e)
        {
            txtfid.IsEnabled = true;
            btngo.Content = "Remove";
            btnaddflight.IsEnabled = false;
            btnreport.IsEnabled = false;
            txtstartdate.IsEnabled = false;
            txtenddate.IsEnabled = false;
            addcanvas.Visibility = Visibility.Hidden;

        }

        //This button will function for both remove flight and generate report
        private void btngo_Click(object sender, RoutedEventArgs e)
        {
            
            if(btngo.Content =="Remove")
            {
                string fid = txtfid.Text;
                try
                {
                    int records = FlightValidation.removeflight(fid);
                    if (records > 0)
                    {
                        MessageBox.Show("Flight removed successfully");
                    }
                    else
                    {
                        throw new FlightException("Flight not removed");
                    }
                }
                catch (FlightException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (SystemException ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }

        }
    }
}
