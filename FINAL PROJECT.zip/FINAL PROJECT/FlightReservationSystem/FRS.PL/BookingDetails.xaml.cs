﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FRS.ENTITY;
using FRS.EXCEPTION;
using FRS.BL;

namespace FRS.PL
{
    /// <summary>
    /// Interaction logic for BookingDetails.xaml
    /// </summary>
    public partial class BookingDetails : Window
    {
        Flight F;
        int totalprice = 0;
        public BookingDetails()
        {
            InitializeComponent();
        }
        public BookingDetails(Flight f)
        {
            InitializeComponent();
            F = f;
        }
        List<Customer> custlist = new List<Customer>();
        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            Customer c = new Customer();
            c.DOB = (dpDOB.Text);
            c.Email = txtemail.Text;
            c.Title = cbTitle.SelectedValue.ToString();

            c.Name = txtname.Text;
            c.MobileNo = txtmobileno.Text;
            if (rdFemale.IsChecked == true)
            {
                c.Gender = "Female";
            }
            else
            {
                c.Gender = "Male";
            }
            custlist.Add(c);
            List<Customer> nc = new List<Customer>();
            nc = custlist;
            BookingConfirmation b = new BookingConfirmation(nc, totalprice, F);
            b.Show();
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            int i = 1;

            while (i < Int32.Parse(txtdisNoOfTickets.Text))
            {
                Customer c = new Customer();
                c.DOB = ((dpDOB.Text));
                c.Email = txtemail.Text;
                c.Title = cbTitle.SelectedValue.ToString();

                c.Name = txtname.Text;
                c.MobileNo = txtmobileno.Text;
                if (rdFemale.IsChecked == true)
                {
                    c.Gender = "Female";
                }
                else
                {
                    c.Gender = "Male";
                }
                custlist.Add(c);
                Clear();
                i++;
                totalprice += int.Parse(F.Fare.ToString());
                txtdisNoOfTickets.IsEnabled = false;
            }
            btnAdd.IsEnabled = false;
        }
        public void Clear()
        {

            txtemail.Text = "";
            txtmobileno.Text = "";
            txtname.Text = "";
            rdFemale.IsChecked = false;
            rdMale.IsChecked = false;
            dpDOB.Text = "";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            btnAdd.IsEnabled = false;
        }

        private void txtdisNoOfTickets_LostFocus(object sender, RoutedEventArgs e)
        {
            if (Int32.Parse(txtdisNoOfTickets.Text) > 1)
            {
                btnAdd.IsEnabled = true;
            }
        }

    }
}
