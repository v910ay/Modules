﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FRS.ENTITY;
using FRS.BL;
using FRS.EXCEPTION;

namespace FRS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
         
          private void btnsearch_Click_1(object sender, RoutedEventArgs e)
          {

              Flight f = new Flight();
              f.Destination = ((ComboBoxItem)cbdestination.SelectedItem).Content.ToString();
              f.Source = ((ComboBoxItem)cbsource.SelectedItem).Content.ToString();
              f.DateOfJourney = dpJourney.SelectedDate.Value;
              Flight s = FlightValidation.SearchFlight(f);
              if (s != null)
              {

                  FlightDetails w = new FlightDetails(s);
                  w.Show();


              }
              else
              {
                  MessageBox.Show("enter valid data");
              }
          }

          private void btnlogin_Click(object sender, RoutedEventArgs e)
          {
              AdminLogin ad = new AdminLogin();
              ad.Show();
              this.Close();
          }

    }
    }

